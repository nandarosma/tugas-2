<div class="container">

<table id="example" class="table table-bordered table-striped table-
hover dt-responsive nowrap" style="width:100%">

<thead class="bg-info">
<tr>
<th scope="col" class="text-center">No</th>
<th scope="col" class="text-center">Nama</th>
<th scope="col" class="text-center">Email</th>
<th scope="col" class="text-center">No. HP</th>
<th scope="col" class="text-center">Alamat</th>
</tr>
</thead>
<tbody class="table-group-divider">
<tr>
<th scope="row" class="text-center">1</th>
<td>Anto Anto</td>
<td class="text-center">anto@alamat-email.com</td>
<td class="text-center">08123456789</td>
<td>Jl. Kalimalang - Cibatu, Cikarang</td>
</tr>
<tr>
<th scope="row" class="text-center">2</th>
<td>Budi Budi</td>
<td class="text-center">budi@alamat-email.com</td>
<td class="text-center">081122334455</td>
<td>Jl. Kalimalang - Cibatu, Cikarang</td>
</tr>
<tr>
<th scope="row" class="text-center">3</th>
<td>Citra Citra</td>
<td class="text-center">citra@alamat-email.com</td>
<td class="text-center">082299887766</td>
<td>Jl. Kalimalang - Cibatu, Cikarang</td>
</tr>
<tr>
<th scope="row" class="text-center">4</th>
<td>Anto Anto</td>
<td class="text-center">anto@alamat-email.com</td>
<td class="text-center">08123456789</td>
<td>Jl. Kalimalang - Cibatu, Cikarang</td>
</tr>
<tr>
<th scope="row" class="text-center">5</th>
<td>Budi Budi</td>
<td class="text-center">budi@alamat-email.com</td>
<td class="text-center">081122334455</td>
<td>Jl. Kalimalang - Cibatu, Cikarang</td>
</tr>
<tr>
<th scope="row" class="text-center">6</th>
<td>Citra Citra</td>
<td class="text-center">citra@alamat-email.com</td>
<td class="text-center">082299887766</td>
<td>Jl. Kalimalang - Cibatu, Cikarang</td>
</tr>
<tr>
<th scope="row" class="text-center">7</th>

Pemrograman Web I – Eko Budiarto 9
Fakultas Teknik - Program Studi Teknik Informatika Universitas Pelita Bangsa

<td>Anto Anto</td>
<td class="text-center">anto@alamat-email.com</td>
<td class="text-center">08123456789</td>
<td>Jl. Kalimalang - Cibatu, Cikarang</td>
</tr>
<tr>
<th scope="row" class="text-center">8</th>
<td>Budi Budi</td>
<td class="text-center">budi@alamat-email.com</td>
<td class="text-center">081122334455</td>
<td>Jl. Kalimalang - Cibatu, Cikarang</td>
</tr>
<tr>
<th scope="row" class="text-center">9</th>
<td>Citra Citra</td>
<td class="text-center">citra@alamat-email.com</td>
<td class="text-center">082299887766</td>
<td>Jl. Kalimalang - Cibatu, Cikarang</td>
</tr>
<tr>
<th scope="row" class="text-center">10</th>
<td>Anto Anto</td>
<td class="text-center">anto@alamat-email.com</td>
<td class="text-center">08123456789</td>
<td>Jl. Kalimalang - Cibatu, Cikarang</td>
</tr>
<tr>
<th scope="row" class="text-center">11</th>
<td>Budi Budi</td>
<td class="text-center">budi@alamat-email.com</td>
<td class="text-center">081122334455</td>
<td>Jl. Kalimalang - Cibatu, Cikarang</td>
</tr>
<tr>
<th scope="row" class="text-center">12</th>
<td>Citra Citra</td>
<td class="text-center">citra@alamat-email.com</td>
<td class="text-center">082299887766</td>
<td>Jl. Kalimalang - Cibatu, Cikarang</td>
</tr>
</tbody>
</table>
</div>